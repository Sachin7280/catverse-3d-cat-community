export const breeds = [
  {
    id: "b1",
    name: "Persian Cat",
    origin: "Iran",
    lifespan: "12-17 years",
    personality: ["Calm", "Affectionate", "Quiet"],
    image: "https://images.unsplash.com/photo-1513245543132-31f507417b26?auto=format&fit=crop&q=80",
    hair: "Long Hair",
    activity: "Calm",
    environment: "Indoor"
  },
  {
    id: "b2",
    name: "Maine Coon",
    origin: "United States",
    lifespan: "12-15 years",
    personality: ["Gentle", "Intelligent", "Playful"],
    image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&q=80",
    hair: "Long Hair",
    activity: "Active",
    environment: "Indoor/Outdoor"
  },
  {
    id: "b3",
    name: "Bengal Cat",
    origin: "United States",
    lifespan: "12-16 years",
    personality: ["Energetic", "Curious", "Agile"],
    image: "https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop&q=80",
    hair: "Short Hair",
    activity: "Active",
    environment: "Indoor"
  },
  {
    id: "b4",
    name: "Siamese Cat",
    origin: "Thailand",
    lifespan: "15-20 years",
    personality: ["Vocal", "Social", "Intelligent"],
    image: "https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?auto=format&fit=crop&q=80",
    hair: "Short Hair",
    activity: "Active",
    environment: "Indoor"
  },
  {
    id: "b5",
    name: "British Shorthair",
    origin: "United Kingdom",
    lifespan: "14-20 years",
    personality: ["Easygoing", "Independent", "Loyal"],
    image: "https://images.unsplash.com/photo-1574158622682-e40e69881006?auto=format&fit=crop&q=80",
    hair: "Short Hair",
    activity: "Calm",
    environment: "Indoor"
  },
  {
    id: "b6",
    name: "Ragdoll",
    origin: "United States",
    lifespan: "13-18 years",
    personality: ["Docile", "Placid", "Affectionate"],
    image: "https://images.unsplash.com/photo-1606214564325-2af8de228830?auto=format&fit=crop&q=80",
    hair: "Long Hair",
    activity: "Calm",
    environment: "Indoor"
  }
];

export const stories = [
  {
    id: "s1",
    title: "Milo's Rescue Journey",
    summary: "From the streets to a loving home.",
    image: "https://images.unsplash.com/photo-1533738363-b7f9aef128ce?auto=format&fit=crop&q=80"
  },
  {
    id: "s2",
    title: "Bella's First Home",
    summary: "A tiny kitten discovers the big world.",
    image: "https://images.unsplash.com/photo-1511275539165-cc4ed0259d64?auto=format&fit=crop&q=80"
  },
  {
    id: "s3",
    title: "Snowy's Transformation",
    summary: "Overcoming fear with love and patience.",
    image: "https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?auto=format&fit=crop&q=80"
  },
  {
    id: "s4",
    title: "Luna's Adventure",
    summary: "The curious cat who explored the world.",
    image: "https://images.unsplash.com/photo-1574144611937-0df059b5ef3e?auto=format&fit=crop&q=80"
  }
];

export const gallery = [
  ...Array.from({ length: 30 }).map((_, i) => ({
    id: `g${i}`,
    url: `https://images.unsplash.com/photo-${[
      '1513245543132-31f507417b26', '1514888286974-6c03e2ca1dba', '1543852786-1cf6624b9987', 
      '1513360371669-4adf3dd7dff8', '1574158622682-e40e69881006', '1606214564325-2af8de228830',
      '1533738363-b7f9aef128ce', '1511275539165-cc4ed0259d64', '1526336024174-e58f5cdd8e13'
    ][i % 9]}?auto=format&fit=crop&q=80`,
    category: ["Cute", "Funny", "Sleeping", "Playing", "White Cats", "Black Cats"][i % 6]
  }))
];

export const adoptions = [
  { id: "a1", name: "Leo", age: "2 months", gender: "Male", city: "Delhi", image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&q=80" },
  { id: "a2", name: "Chloe", age: "1 year", gender: "Female", city: "Mumbai", image: "https://images.unsplash.com/photo-1574158622682-e40e69881006?auto=format&fit=crop&q=80" },
  { id: "a3", name: "Simba", age: "6 months", gender: "Male", city: "Bangalore", image: "https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop&q=80" },
  { id: "a4", name: "Nala", age: "3 years", gender: "Female", city: "Kolkata", image: "https://images.unsplash.com/photo-1513245543132-31f507417b26?auto=format&fit=crop&q=80" },
  { id: "a5", name: "Oliver", age: "4 months", gender: "Male", city: "Patna", image: "https://images.unsplash.com/photo-1511275539165-cc4ed0259d64?auto=format&fit=crop&q=80" },
  { id: "a6", name: "Lily", age: "2 years", gender: "Female", city: "Ranchi", image: "https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?auto=format&fit=crop&q=80" }
];

export const products = [
  { id: "p1", name: "Premium Cat Food", price: "₹1,200", image: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&q=80", category: "Food" },
  { id: "p2", name: "Luxury Cat Tree", price: "₹4,500", image: "https://images.unsplash.com/photo-1545249390-6bdfa286032f?auto=format&fit=crop&q=80", category: "Toys" },
  { id: "p3", name: "Cozy Plush Bed", price: "₹2,100", image: "https://images.unsplash.com/photo-1615826932727-463d1223e7bd?auto=format&fit=crop&q=80", category: "Beds" },
  { id: "p4", name: "Ceramic Bowl Set", price: "₹800", image: "https://images.unsplash.com/photo-1623512270966-2ebfcc2894db?auto=format&fit=crop&q=80", category: "Bowls" }
];
