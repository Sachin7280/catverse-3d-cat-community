/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Lenis from "@studio-freight/lenis";

import { Layout } from "./components/Layout";
import { HomePage } from "./pages/HomePage";
import { BreedsPage } from "./pages/BreedsPage";
import { AdoptPage } from "./pages/AdoptPage";
import { CarePage } from "./pages/CarePage";
import { StoriesPage } from "./pages/StoriesPage";
import { GalleryPage } from "./pages/GalleryPage";
import { ShopPage } from "./pages/ShopPage";
import { AboutPage } from "./pages/AboutPage";
import { ContactPage } from "./pages/ContactPage";
import { CustomCursor } from "./components/CustomCursor";

export default function App() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: "vertical",
      gestureOrientation: "vertical",
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <BrowserRouter>
      <CustomCursor />
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/breeds" element={<BreedsPage />} />
          <Route path="/adopt" element={<AdoptPage />} />
          <Route path="/care" element={<CarePage />} />
          <Route path="/stories" element={<StoriesPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/shop" element={<ShopPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
