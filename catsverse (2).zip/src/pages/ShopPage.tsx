import { motion } from "framer-motion";
import { products } from "../data/demo";
import { ShoppingBag, Heart } from "lucide-react";
import { TiltCard } from "../components/TiltCard";

export function ShopPage() {
  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12 relative">
       <div className="absolute top-1/4 right-0 w-[600px] h-[600px] bg-gradient-to-l from-white/5 to-transparent blur-[120px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-[1600px] mx-auto">
        <div className="mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-heading font-extrabold mb-6"
          >
            Premium Care
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 max-w-2xl text-balance"
          >
            Exclusive toys, food, and accessories for your feline royalty.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product, i) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={product.id}
            >
              <TiltCard className="bg-[#050505] border border-white/5 p-4 group">
                <div className="relative aspect-square rounded-2xl overflow-hidden mb-6">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-3 right-3">
                    <button className="p-2 glass-panel rounded-full hover:bg-white hover:text-black transition-colors">
                      <Heart className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium">
                    {product.category}
                  </div>
                </div>
                <div>
                  <h3 className="font-heading font-bold text-lg mb-1">{product.name}</h3>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-[#C8B6FF] font-medium text-lg">{product.price}</span>
                    <button className="p-3 bg-white text-black rounded-full hover:bg-[#C8B6FF] transition-colors">
                      <ShoppingBag className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
