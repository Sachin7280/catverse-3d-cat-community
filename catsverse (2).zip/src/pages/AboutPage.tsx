import { motion } from "framer-motion";

export function AboutPage() {
  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12 relative">
      <div className="max-w-[1600px] mx-auto">
        <div className="text-center mb-20 max-w-3xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-heading font-extrabold mb-6"
          >
            Our Mission
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 text-balance"
          >
            We believe every cat deserves a loving home and every home deserves the joy of a cat.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-32">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative rounded-[3rem] overflow-hidden aspect-square"
          >
            <img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&q=80" alt="About us" className="w-full h-full object-cover" />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-3xl font-heading font-bold mb-4">The CatsVerse Vision</h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                Founded with a deep love for felines, CatsVerse aims to bridge the gap between cats in need and families looking for a forever friend. We focus on education, beautiful design, and seamless experiences to bring the magical world of cats to India.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="p-6 rounded-2xl glass-panel">
                <div className="text-3xl font-heading font-bold text-[#C8B6FF] mb-2">10K+</div>
                <div className="text-sm font-medium text-gray-400">Adoptions Facilitated</div>
              </div>
              <div className="p-6 rounded-2xl glass-panel">
                <div className="text-3xl font-heading font-bold text-[#C8B6FF] mb-2">50+</div>
                <div className="text-sm font-medium text-gray-400">Partner Shelters</div>
              </div>
            </div>
          </motion.div>
        </div>

      </div>
    </div>
  );
}
