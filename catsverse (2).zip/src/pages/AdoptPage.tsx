import { motion } from "framer-motion";
import { Navigation, Heart } from "lucide-react";
import { adoptions } from "../data/demo";

export function AdoptPage() {
  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12 relative">
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-bl from-[#C8B6FF]/10 to-transparent blur-[120px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-[1600px] mx-auto">
        <div className="mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-heading font-extrabold mb-6"
          >
            Adopt A Friend
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 max-w-2xl text-balance"
          >
            These lovely felines are waiting for their forever homes. Find your perfect companion today.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {adoptions.map((adopt, idx) => (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                key={adopt.id} 
                className="bg-[#050505] rounded-[2rem] overflow-hidden group border border-white/5 hover:border-[#C8B6FF]/50 transition-colors duration-500"
              >
                <div className="relative h-[300px] overflow-hidden">
                  <img src={adopt.image} alt={adopt.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-md px-4 py-2 rounded-full flex items-center gap-2 text-sm font-medium border border-white/10">
                    <Navigation className="w-4 h-4 text-[#C8B6FF]" />
                    {adopt.city}
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex items-end justify-between mb-6">
                    <div>
                      <h3 className="text-3xl font-bold font-heading mb-1">{adopt.name}</h3>
                      <p className="text-gray-400">{adopt.age} • {adopt.gender}</p>
                    </div>
                  </div>
                  <button className="w-full py-4 rounded-full bg-[#111111] hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2 font-bold group/btn border border-white/5 hover:border-white">
                    <Heart className="w-5 h-5 group-hover/btn:fill-current transition-colors" />
                    Adopt {adopt.name}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>

      </div>
    </div>
  );
}
