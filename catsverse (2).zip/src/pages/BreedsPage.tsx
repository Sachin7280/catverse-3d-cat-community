import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Star, Filter } from "lucide-react";
import { breeds } from "../data/demo";
import { TiltCard } from "../components/TiltCard";

const filters = ["All", "Long Hair", "Short Hair", "Active", "Calm", "Indoor", "Outdoor"];

export function BreedsPage() {
  const [activeFilter, setActiveFilter] = useState("All");
  const [search, setSearch] = useState("");

  const filteredBreeds = breeds.filter(breed => {
    const matchesSearch = breed.name.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = activeFilter === "All" || 
      breed.hair === activeFilter ||
      breed.activity === activeFilter ||
      breed.environment.includes(activeFilter);
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12">
      <div className="max-w-[1600px] mx-auto">
        <div className="mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-heading font-extrabold mb-6"
          >
            Cat Breeds
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 max-w-2xl text-balance"
          >
            Explore our comprehensive encyclopedia of cat breeds. From majestic Maine Coons to elegant Persians.
          </motion.p>
        </div>

        <div className="flex flex-col md:flex-row gap-6 mb-12 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input 
              type="text" 
              placeholder="Search breeds..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#111111] border border-white/10 rounded-full py-4 pl-12 pr-6 text-white placeholder-gray-500 focus:outline-none focus:border-[#C8B6FF] transition-colors"
            />
          </div>
          <div className="flex gap-3 overflow-x-auto w-full md:w-auto pb-4 md:pb-0 hide-scrollbar" style={{ scrollbarWidth: 'none' }}>
            {filters.map(filter => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`whitespace-nowrap px-6 py-3 rounded-full border transition-colors ${
                  activeFilter === filter 
                    ? "bg-[#C8B6FF] text-black border-[#C8B6FF] font-medium" 
                    : "border-white/10 text-gray-400 hover:text-white hover:border-white/30"
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredBreeds.map((breed, i) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                key={breed.id}
              >
                <TiltCard className="aspect-[4/5] bg-gradient-to-b from-white/5 to-white/0 border border-white/10 group cursor-pointer">
                  <img src={breed.image} alt={breed.name} className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-8 w-full z-10">
                    <h3 className="text-3xl font-heading font-bold mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">{breed.name}</h3>
                    <div className="space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                       <p className="text-sm text-gray-300">Origin: {breed.origin}</p>
                       <p className="text-sm text-gray-300">Life: {breed.lifespan}</p>
                       <div className="flex flex-wrap gap-2 mt-3">
                         {breed.personality.map(p => (
                           <span key={p} className="text-xs px-2 py-1 bg-white/10 rounded-full backdrop-blur-md border border-white/10">
                             {p}
                           </span>
                         ))}
                       </div>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
        
        {filteredBreeds.length === 0 && (
          <div className="text-center py-20 text-gray-500 text-lg">
            No breeds found matching your criteria.
          </div>
        )}
      </div>
    </div>
  );
}
