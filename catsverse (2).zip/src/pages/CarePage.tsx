import { motion } from "framer-motion";
import { ArrowRight, Utensils, HeartPulse, Sparkles, Activity } from "lucide-react";

const careTopics = [
  { icon: Utensils, title: "Nutrition", desc: "A balanced diet is crucial. Learn what dry and wet foods work best." },
  { icon: HeartPulse, title: "Health", desc: "Regular vet checkups, vaccinations, and preventive care tips." },
  { icon: Sparkles, title: "Grooming", desc: "Keep their coat shiny and claws trimmed properly." },
  { icon: Activity, title: "Exercise", desc: "Interactive play sessions to keep them agile and entertained." }
];

export function CarePage() {
  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12">
      <div className="max-w-[1600px] mx-auto">
        <div className="mb-20 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-heading font-extrabold mb-6 text-center"
          >
            Feline Care Guide
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 max-w-2xl text-balance mx-auto"
          >
            Everything you need to know to give your cat the best life possible.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-24">
          {careTopics.map((topic, i) => (
             <motion.div
               initial={{ opacity: 0, y: 30 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ delay: i * 0.1 }}
               key={topic.title}
               className="p-8 rounded-3xl bg-[#050505] border border-white/5 hover:border-[#C8B6FF]/30 transition-colors group cursor-pointer"
             >
               <div className="w-14 h-14 bg-[#111111] rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                 <topic.icon className="w-6 h-6 text-[#C8B6FF]" />
               </div>
               <h3 className="text-2xl font-bold font-heading mb-3">{topic.title}</h3>
               <p className="text-gray-400 mb-6">{topic.desc}</p>
               <div className="flex items-center text-[#C8B6FF] text-sm font-medium">
                 Read Guide <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
               </div>
             </motion.div>
          ))}
        </div>

        {/* Featured Article */}
        <div className="relative rounded-[3rem] overflow-hidden">
          <img src="https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop&q=80" alt="Cat care" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent" />
          
          <div className="relative z-10 p-12 md:p-24 flex flex-col items-start max-w-3xl">
            <div className="glass-panel px-4 py-1 rounded-full text-sm font-medium mb-6">Expert Advice</div>
            <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6 leading-tight">The Ultimate Checklist for New Cat Parents</h2>
            <p className="text-xl text-gray-300 mb-8">Bringing a new kitten home? Here is everything you need to prepare, from litter boxes to scratching posts.</p>
            <button className="px-8 py-4 bg-white text-black rounded-full font-bold hover:scale-105 transition-transform flex items-center gap-2">
               Read Article <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
