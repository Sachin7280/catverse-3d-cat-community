import React, { useState } from "react";
import { motion } from "framer-motion";
import { Send, MapPin, Mail, Phone } from "lucide-react";

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12 relative">
      <div className="max-w-[1600px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="text-5xl md:text-7xl font-heading font-extrabold mb-6">
              Get in Touch
            </h1>
            <p className="text-xl text-gray-400 mb-12 max-w-lg">
              Have questions about adoption, care, or our premium products? We're here to help you and your feline friends.
            </p>

            <div className="space-y-8 mb-12">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full glass-panel flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5 text-[#C8B6FF]" />
                </div>
                <div>
                  <h3 className="font-heading font-bold text-lg">Email Us</h3>
                  <p className="text-gray-400">hello@catsverse.demo</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full glass-panel flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 text-[#C8B6FF]" />
                </div>
                <div>
                  <h3 className="font-heading font-bold text-lg">Call Us</h3>
                  <p className="text-gray-400">+91 98765 43210</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full glass-panel flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-[#C8B6FF]" />
                </div>
                <div>
                  <h3 className="font-heading font-bold text-lg">HQ Location</h3>
                  <p className="text-gray-400">123 Feline Avenue, Bandra West<br/>Mumbai, MH 400050</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="p-8 md:p-12 glass-panel rounded-[2.5rem]"
          >
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-20">
                <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center text-green-500">
                  <Send className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold font-heading">Message Sent!</h3>
                <p className="text-gray-400">We'll get back to you purr-fectly soon.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">First Name</label>
                    <input required type="text" className="w-full bg-[#050505] border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#C8B6FF] transition-colors text-white" placeholder="John" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Last Name</label>
                    <input required type="text" className="w-full bg-[#050505] border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#C8B6FF] transition-colors text-white" placeholder="Doe" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Email Address</label>
                  <input required type="email" className="w-full bg-[#050505] border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#C8B6FF] transition-colors text-white" placeholder="john@example.com" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Message</label>
                  <textarea required rows={4} className="w-full bg-[#050505] border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#C8B6FF] transition-colors text-white resize-none" placeholder="How can we help?"></textarea>
                </div>
                <button type="submit" className="w-full py-4 bg-white text-black font-bold rounded-xl hover:bg-[#C8B6FF] transition-colors flex items-center justify-center gap-2">
                  Send Message
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </motion.div>

        </div>
      </div>
    </div>
  );
}
