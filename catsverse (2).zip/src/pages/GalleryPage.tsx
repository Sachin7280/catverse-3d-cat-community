import { motion } from "framer-motion";
import { gallery } from "../data/demo";
import { useState } from "react";
import { Maximize2, X } from "lucide-react";

export function GalleryPage() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  // Simple pseudo-masonry with CSS columns
  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12">
      <div className="max-w-[1600px] mx-auto">
        <div className="mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-heading font-extrabold mb-6"
          >
            Cat Gallery
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 max-w-2xl text-balance"
          >
            A curated collection of beautiful felines from around the world.
          </motion.p>
        </div>

        <div className="columns-1 sm:columns-2 md:columns-3 lg:columns-4 gap-6 space-y-6">
          {gallery.map((img, i) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: (i % 10) * 0.1 }}
              key={img.id}
              className="relative group rounded-2xl overflow-hidden cursor-zoom-in break-inside-avoid"
              onClick={() => setSelectedImage(img.url)}
            >
              <img src={img.url} alt={img.category} className="w-full object-cover group-hover:scale-105 transition-transform duration-700" />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Maximize2 className="w-8 h-8 text-white" />
              </div>
              <div className="absolute bottom-4 left-4 glass-panel px-3 py-1 rounded-full text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0">
                {img.category}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {selectedImage && (
        <div className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center p-6" onClick={() => setSelectedImage(null)}>
          <button className="absolute top-6 right-6 text-white hover:text-[#C8B6FF] transition-colors" onClick={() => setSelectedImage(null)}>
            <X className="w-8 h-8" />
          </button>
          <motion.img 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            src={selectedImage} 
            className="max-w-full max-h-[90vh] object-contain rounded-lg" 
            onClick={e => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
