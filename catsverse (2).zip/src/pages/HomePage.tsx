import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Play, Heart, Star, Navigation } from "lucide-react";
import { TiltCard } from "../components/TiltCard";
import { Counter } from "../components/Counter";
import { breeds, stories, adoptions } from "../data/demo";

export function HomePage() {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative min-h-screen w-full flex flex-col items-center justify-end overflow-hidden pt-32 pb-16 md:pb-24">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover scale-105"
        >
          <source src="https://res.cloudinary.com/djsurxemd/video/upload/v1781535511/white_cat_and_black_backgound_jixi8k.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/20 to-[#050505] pointer-events-none"></div>
        
        <div className="relative z-10 max-w-[1600px] mx-auto px-6 md:px-12 w-full flex flex-col items-center justify-end flex-grow pb-8 md:pb-12">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full"
          >
            <Link to="/breeds" className="w-full sm:w-auto px-10 py-5 rounded-full bg-white text-black font-semibold hover:scale-105 transition-transform flex items-center justify-center gap-2">
              Explore Cats
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link to="/stories" className="w-full sm:w-auto px-10 py-5 rounded-full glass-panel hover:bg-white/10 transition-colors flex items-center justify-center gap-2">
              <Play className="w-5 h-5" />
              Watch Stories
            </Link>
          </motion.div>
        </div>

        {/* Floating gradient orb for subtle color */}
        <div className="absolute top-1/2 left-3/4 -translate-y-1/2 w-96 h-96 bg-[#C8B6FF] rounded-full blur-[120px] opacity-20 pointer-events-none mix-blend-screen" />
      </section>

      {/* Stats Section */}
      <section className="py-16 md:py-24 border-y border-white/5 relative z-20 bg-[#050505]">
        <div className="max-w-[1600px] mx-auto px-6 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 divide-x divide-white/5 text-center">
          {[
             { label: "Happy Cat Lovers", value: 25, suffix: "K+" },
             { label: "Cat Breeds", value: 500, suffix: "+" },
             { label: "Adoptions", value: 10, suffix: "K+" },
             { label: "Monthly Visitors", value: 1, suffix: "M+" }
          ].map((stat, i) => (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              key={stat.label} 
              className="flex flex-col gap-2"
            >
              <div className="text-4xl md:text-5xl font-heading font-bold text-white">
                <Counter end={stat.value} suffix={stat.suffix} />
              </div>
              <div className="text-sm md:text-base text-gray-400 font-medium">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Breeds - 3D Cards */}
      <section className="py-20 md:py-32 bg-[#111111] relative isolate">
        {/* bg decorative element */}
        <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80" aria-hidden="true">
          <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#C8B6FF] to-[#D9D9D9] opacity-10 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]" style={{ clipPath: 'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)'}}></div>
        </div>

        <div className="max-w-[1600px] mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 md:mb-16 gap-6">
            <div>
              <h2 className="text-3xl md:text-5xl font-heading font-bold mb-4">Featured Breeds</h2>
              <p className="text-gray-400 max-w-xl text-base md:text-lg">Swipe through our curated list of the most elegant and requested cat breeds across India.</p>
            </div>
            <Link to="/breeds" className="text-[#C8B6FF] flex items-center gap-2 hover:opacity-80 transition-opacity">
              View All Breeds <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {breeds.slice(0, 6).map((breed, i) => (
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                key={breed.id}
              >
                <TiltCard className="aspect-[4/5] bg-gradient-to-b from-white/5 to-white/0 border border-white/10 group cursor-pointer">
                  <img src={breed.image} alt={breed.name} className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-8 w-full z-10">
                    <h3 className="text-2xl font-heading font-bold mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">{breed.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                      <Star className="w-4 h-4 text-[#C8B6FF]" />
                      {breed.personality.join(", ")}
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Cat Personality Quiz Demo */}
      <section className="py-16 md:py-24 bg-[#050505]">
        <div className="max-w-[1600px] mx-auto px-6 md:px-12 text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="glass-panel p-8 md:p-20 rounded-[2rem] md:rounded-[3rem] relative overflow-hidden group"
          >
             <div className="absolute inset-0 bg-gradient-to-r from-[#C8B6FF]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
             
             <h2 className="text-3xl md:text-[48px] font-heading font-bold mb-4 md:mb-6 leading-tight">Find Your Feline Match</h2>
             <p className="text-lg md:text-xl text-gray-400 mb-8 md:mb-12 max-w-2xl mx-auto">Take our interactive AI-powered quiz to discover which cat breed perfectly complements your lifestyle.</p>
             
             <div className="flex flex-wrap justify-center gap-4 mb-12">
               {["Calm & Quiet", "Energetic & Playful", "Lazy Couch Potato", "Curious Explorer"].map((trait) => (
                 <button key={trait} className="px-6 py-3 rounded-full border border-white/20 hover:border-[#C8B6FF] hover:bg-[#C8B6FF]/10 transition-all font-medium">
                   {trait}
                 </button>
               ))}
             </div>

             <button className="w-full sm:w-auto px-8 md:px-10 py-4 bg-white text-black font-bold rounded-full hover:scale-105 transition-transform flex items-center justify-center gap-2 mx-auto">
               Start Demo Quiz
               <ArrowRight className="w-5 h-5" />
             </button>
          </motion.div>
        </div>
      </section>

      {/* Adoption Section */}
      <section className="py-20 md:py-32 bg-[#111111]">
        <div className="max-w-[1600px] mx-auto px-6 md:px-12">
          <div className="text-center mb-12 md:mb-20">
            <h2 className="text-3xl md:text-[48px] font-heading font-bold mb-4">Awaiting Adoption</h2>
            <p className="text-gray-400 text-base md:text-lg max-w-2xl mx-auto">Give them the home they deserve. Browse our demo adoption listings across major Indian cities.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {adoptions.slice(0, 3).map((adopt, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                key={adopt.id} 
                className="bg-[#050505] rounded-3xl overflow-hidden group border border-white/5 hover:border-white/20 transition-colors"
              >
                <div className="relative h-64 overflow-hidden">
                  <img src={adopt.image} alt={adopt.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full flex items-center gap-1 text-sm">
                    <Navigation className="w-4 h-4 text-[#C8B6FF]" />
                    {adopt.city}
                  </div>
                </div>
                <div className="p-8 flex flex-col items-center text-center">
                  <h3 className="text-2xl font-bold font-heading mb-2">{adopt.name}</h3>
                  <p className="text-gray-400 mb-6">{adopt.age} • {adopt.gender}</p>
                  <button className="w-full py-3 rounded-full glass-panel hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2 font-medium">
                    <Heart className="w-4 h-4" />
                    Adopt Me
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/adopt" className="inline-flex px-8 py-3 rounded-full border border-white/20 hover:bg-white/5 transition-colors">
              View All Pets
            </Link>
          </div>
        </div>
      </section>

      {/* Stories - Horizontal Scroll (Simulated for Demo) */}
      <section className="py-20 md:py-32 bg-[#050505] overflow-hidden">
        <div className="max-w-[1600px] mx-auto px-6 md:px-12 mb-10 md:mb-16">
          <h2 className="text-3xl md:text-[48px] font-heading font-bold mb-4">Heartwarming Stories</h2>
        </div>
        
        {/* Horizontal flex container with snap scroll */}
        <div className="flex gap-4 md:gap-6 overflow-x-auto pb-12 px-6 md:px-12 max-w-[1600px] mx-auto snap-x snap-mandatory hide-scrollbar" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
           {stories.map((story, i) => (
             <motion.div 
               whileHover={{ scale: 0.98 }}
               key={story.id} 
               className="min-w-[300px] md:min-w-[400px] aspect-[4/3] rounded-3xl overflow-hidden relative snap-center cursor-pointer shrink-0"
             >
               <img src={story.image} alt={story.title} className="w-full h-full object-cover" />
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent p-8 flex flex-col justify-end">
                 <h3 className="text-2xl font-bold font-heading mb-2">{story.title}</h3>
                 <p className="text-gray-300 text-sm line-clamp-2">{story.summary}</p>
               </div>
             </motion.div>
           ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 md:py-40 relative isolate bg-black overflow-hidden border-t border-white/10">
        <div className="absolute -z-10 absolute-center w-[600px] md:w-[800px] h-[600px] md:h-[800px] bg-gradient-to-r from-[#C8B6FF]/20 to-transparent blur-[80px] md:blur-[100px] rounded-full top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
        
        <div className="max-w-[1600px] mx-auto px-6 md:px-12 text-center z-10 relative">
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl lg:text-[72px] font-heading font-extrabold mb-8 tracking-tight leading-tight"
          >
            Ready To Meet Your <span className="text-[#C8B6FF]">Perfect</span> Cat?
          </motion.h2>
          <motion.div
             initial={{ opacity: 0 }}
             whileInView={{ opacity: 1 }}
             viewport={{ once: true }}
             transition={{ delay: 0.2 }}
          >
            <Link to="/breeds" className="inline-flex px-10 py-5 rounded-full bg-white text-black font-bold text-lg hover:scale-105 transition-transform">
              Explore The Universe
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

