import { motion } from "framer-motion";
import { stories } from "../data/demo";
import { TiltCard } from "../components/TiltCard";
import { PlayCircle } from "lucide-react";

export function StoriesPage() {
  return (
    <div className="pt-32 pb-24 min-h-screen px-6 md:px-12 relative">
       <div className="absolute top-0 right-1/4 w-[800px] h-[800px] bg-gradient-to-br from-[#C8B6FF]/10 to-transparent blur-[120px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-[1600px] mx-auto">
        <div className="mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-heading font-extrabold mb-6"
          >
            Heartwarming Stories
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 max-w-2xl text-balance"
          >
            Real stories of rescue, love, and the magical bond between humans and cats.
          </motion.p>
        </div>

        <div className="space-y-12">
          {stories.map((story, idx) => (
            <motion.div
               initial={{ opacity: 0, y: 40 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true, margin: "-100px" }}
               transition={{ duration: 0.6 }}
               key={story.id} 
               className={`flex flex-col ${idx % 2 !== 0 ? 'md:flex-row-reverse' : 'md:flex-row'} items-center gap-12`}
            >
               <div className="w-full md:w-1/2">
                 <TiltCard className="aspect-[4/3]">
                    <img src={story.image} alt={story.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <PlayCircle className="w-16 h-16 text-white" />
                    </div>
                 </TiltCard>
               </div>
               <div className="w-full md:w-1/2">
                  <div className="flex items-center gap-4 mb-4">
                     <span className="text-xs font-bold text-[#C8B6FF] uppercase tracking-wider">Rescue Tale</span>
                     <span className="text-gray-500 text-sm">2 days ago</span>
                  </div>
                  <h2 className="text-4xl font-heading font-bold mb-4">{story.title}</h2>
                  <p className="text-gray-400 text-lg mb-8">{story.summary} The journey from finding them on the streets to seeing them flourish in a loving environment is nothing short of miraculous. These stories inspire us every day.</p>
                  
                  <button className="px-8 py-3 rounded-full border border-white/20 hover:bg-white hover:text-black transition-colors font-medium">
                    Read Full Story
                  </button>
               </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
