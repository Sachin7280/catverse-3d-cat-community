import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Cat, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

const links = [
  { name: "Home", path: "/" },
  { name: "Breeds", path: "/breeds" },
  { name: "Adopt", path: "/adopt" },
  { name: "Care", path: "/care" },
  { name: "Stories", path: "/stories" },
  { name: "Gallery", path: "/gallery" },
  { name: "Shop", path: "/shop" },
];

export function Layout({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-black text-white relative">
      <nav
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          scrolled ? "glass-panel" : "bg-transparent py-4"
        }`}
      >
        <div className="max-w-[1600px] mx-auto px-6 md:px-12 h-24 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <Cat className="w-8 h-8 group-hover:text-[#C8B6FF] transition-colors" />
            <span className="font-heading font-bold text-2xl tracking-tight">CatsVerse</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="text-sm font-medium text-gray-300 hover:text-white transition-colors relative group"
              >
                {link.name}
                {location.pathname === link.path && (
                  <motion.div
                    layoutId="nav-pill"
                    className="absolute -bottom-2 left-0 right-0 h-0.5 bg-[#C8B6FF]"
                  />
                )}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Link
              to="/contact"
              className="px-6 py-2 rounded-full bg-white text-black font-medium hover:bg-[#D9D9D9] transition-colors"
            >
              Contact
            </Link>
          </div>

          {/* Mobile Toggle */}
          <button
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-black/95 backdrop-blur-xl md:hidden pt-24 px-6 flex flex-col gap-6"
          >
            {links.map((link) => (
               <Link
               key={link.path}
               to={link.path}
               className="text-2xl font-heading font-bold"
             >
               {link.name}
             </Link>
            ))}
            <Link
              to="/contact"
              className="text-2xl font-heading font-bold text-[#C8B6FF]"
            >
              Contact Us
            </Link>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="w-full">{children}</main>

      <footer className="bg-[#111111] py-16 mt-24 border-t border-white/10">
        <div className="max-w-[1600px] mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <Cat className="w-8 h-8 text-[#C8B6FF]" />
              <span className="font-heading font-bold text-2xl tracking-tight">CatsVerse</span>
            </Link>
            <p className="text-gray-400 mb-8 max-w-sm">
              Where every cat has a story. Discover rare breeds, amazing care tips, and premium 
              accessories for your feline companions.
            </p>
          </div>
          <div>
            <h4 className="font-heading font-bold text-lg mb-6">Explore</h4>
            <ul className="flex flex-col gap-4 text-gray-400">
              <li><Link to="/breeds" className="hover:text-white transition-colors">Breeds</Link></li>
              <li><Link to="/adopt" className="hover:text-white transition-colors">Adopt</Link></li>
              <li><Link to="/stories" className="hover:text-white transition-colors">Stories</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-heading font-bold text-lg mb-6">Connect</h4>
            <ul className="flex flex-col gap-4 text-gray-400">
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><a href="#" className="hover:text-white transition-colors">Instagram</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-[1600px] mx-auto px-6 md:px-12 mt-16 pt-8 border-t border-white/10 text-center text-gray-500 text-sm">
          © 2024 CatsVerse. All rights reserved. Demo Site.
        </div>
      </footer>
    </div>
  );
}
